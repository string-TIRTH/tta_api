
async function customer_recharge(nCustId,nPlanId,nAmt,nGSTAmt,nTotalAmt){
    let date = new Date();
    var d = date.getDate();
    let http = require("http")
    var result  = await http.request()
    .input('nCustId',mssql.Int,nCustId)
    .input('nPlanId',mssql.Int,nPlanId)
    .input('nAmt',mssql.Float,nAmt)
    .input('nGSTAmt',mssql.Float,nGSTAmt)
    .input('nTotalAmt',mssql.Float,nTotalAmt)
    .input('dGetdate',mssql.DateTime,d)
    .query("insert into  CustomerRecharge  values ( @nCustId, @nPlanId, @nAmt,@nGSTAmt , @nTotalAmt, null, 0, GETDATE(),null, null, null, null, null)");
    
    return result
}

module.exports
{
    customer_recharge : customer_recharge
}