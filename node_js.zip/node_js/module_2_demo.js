const tirth = 'tirth'
const tirth2 = 'tirth2'


module.exports= {tirth,tirth2}