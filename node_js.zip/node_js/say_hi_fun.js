function sayHi (name) {
    console.log('hello '+name);
}

sayHi('tirth')
module.export = sayHi
