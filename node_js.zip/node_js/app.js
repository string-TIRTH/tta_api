//Event Loop Stages :- Request , Register Call Back , Complete Call Back , Execute Call Back
// Basically Even if the request has been completed it will first execute the defualt code first and then will execute the callback code
// setTimeout(()=>{
//     console.log('callback check')
//             },3)

// const http = require('http')
// const name = 'Vraj'
// const server =  http.createServer( (req,res)=>{
//     if(req.url==='/vraj')
//        { res.writeHead(200,{'content-type':'text/html'})
//         res.write(`<h1>Welcome Aboard ${name}</h1>`)
//         res.end()}
// })
// server.listen(5000)
// app.get('/vraj',(req,res)=>{
//     res.send('Hello Vraj')
// })
// app.listen(5000,()=>{
//     console.log('hehe')
// })
const functions = require('./functions')
const express = require('express')
//const bodyParser = require('body-parser')
//const cors = require('cors')
const router = express.Router()
const app = express()

//app.use(bodyParser.urlencoded({extended: true}))
//app.use(bodyParser.json())
//app.use(cors())
app.use('/api',router)
router.route('/astrologer').get((req,res)=>{
    functions.astrologer().then(result => {
        console.log(result)
        const myjson = JSON.stringify(result)
        //res.end(result)
        res.send(myjson)
    })    
})
router.route('/astro_list:nCustId/:nPlanId/:nAmt,/:nGSTAmt/:nTotalAmt').post((req,res)=>{
    functions.customer_recharger.then(result => {
        console.log(result)
        const myjson = JSON.stringify(result)
        //res.end(result)
        res.send(myjson)
    })    
})



app.listen(5000)



