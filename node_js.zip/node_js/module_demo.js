

const names = require('./module_2_demo')
sayHi = require('./say_hi_fun')
console.log(names)
sayHi(names.tirth)
sayHi(names.tirth2)